interface Window {
    ethereum?: any;
  }